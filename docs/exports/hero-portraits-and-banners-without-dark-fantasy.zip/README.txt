Portrait and banner artwork exported from the current game.
10 heroes / 20 original WebP images. No resizing, cropping or re-encoding.
Included: bailong, yuezheng, moye, tangxun, linxue, garrick, kael, mirelle, sylvara, elira
Excluded Dark Fantasy team: vaelric, draeven, mordrienne, sylas, lucien
Portraits are under portraits/ and banners under banners/.
