Eldervane material icon prompt pack — 21 existing item IDs.

กติกายืนยัน:เมื่อฮีโร่เลื่อนขั้นครบ หินส่วนเกินของตัวนั้นแปลงเป็นหินรวม1:1 (ยังไม่ลงruntime) เริ่มอ่านSTYLE_GUIDE.md แล้วใช้prompts/<id>.txtเจนทีละชิ้น; หินเฉพาะฮีโร่เลือกhero-stones/<heroId>/<baseItemId>.txtและแนบportraitตามREFERENCE URL ไฟล์txtแต่ละชิ้นคัดลอกใช้ได้เดี่ยว รายละเอียดหน้าที่จริง/ข้อเสนอภาพดูGENERATION_PROMPTS.md ระบบautomationดูprompts.jsonและmanifest.json อาร์ตยังไม่ได้genหรืออนุมัติ
