90 generated hero-bound breakthrough art variants: 15 heroes x (3 whole stones + 3 matching fragments).
512x512 RGBA PNG with transparent padding. These are art variants, not new inventory IDs.
